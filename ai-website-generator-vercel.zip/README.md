# 🚀 AI Website Generator (Vercel-Only Setup)

This project lets users create websites using AI — fully hosted on **Vercel** (no backend servers required).

## 📂 Project Structure
- `/client` → React + Tailwind frontend (Vite)
- `/api/generate-site.js` → Serverless backend function for OpenAI
- `vercel.json` → Configures routing for frontend + backend

## ⚙️ Setup Instructions

### 1. Add API Key
On your [Vercel Project Dashboard](https://vercel.com/):
- Go to **Settings → Environment Variables**
- Add:
```
OPENAI_API_KEY=your_real_api_key_here
```

### 2. Deploy
1. Push this project to GitHub/GitLab/Bitbucket
2. Go to [Vercel New Project](https://vercel.com/new)
3. Import repository
4. Vercel auto-detects frontend + backend using `vercel.json`
5. Deploy 🎉

### 3. Run Locally (Optional)
Frontend:
```bash
cd client
npm install
npm run dev
```

Backend (serverless local test):
```bash
vercel dev
```

---

After deployment you’ll have:
- Frontend: `https://your-ai-site.vercel.app`
- Backend API: `https://your-ai-site.vercel.app/api/generate-site`

🎉 All in one Vercel app!
